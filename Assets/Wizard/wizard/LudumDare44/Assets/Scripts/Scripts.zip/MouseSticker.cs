﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class MouseSticker : MonoBehaviour {

	private void LateUpdate() {
		
	}
}
